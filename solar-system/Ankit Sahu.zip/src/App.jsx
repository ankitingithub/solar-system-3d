<>
  <Controls speeds={speeds} setSpeeds={setSpeeds} />
  <div style={{ width: '100vw', height: '100vh' }}>
    <SolarSystem speeds={speeds} />
  </div>
</>
